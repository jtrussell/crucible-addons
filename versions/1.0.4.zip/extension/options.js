window.addEventListener('load', () => {
  const uiEl = document.getElementById('ui');
  const deckTrackerEl = document.getElementById('deck-tracker');

  function saveOptions() {
    const uiEnabled = uiEl.checked;
    const deckTracker = deckTrackerEl.checked;

    if (uiEnabled) {
      deckTrackerEl.removeAttribute('disabled');
    } else {
      deckTrackerEl.setAttribute('disabled', !uiEnabled);
    }

    chrome.storage.sync.set({
      uiEnabled,
      deckTracker,
    }, function() {
      const status = document.getElementById('status');
      status.textContent = 'Saved. Please refresh thecrucible.online';
      setTimeout(function() {
        status.textContent = '';
      }, 5000);
    });
  }

  function restoreOptions() {
    chrome.storage.sync.get({
      uiEnabled: false,
      deckTracker: true,
    }, function(items) {
      uiEl.checked = items.uiEnabled;
      deckTrackerEl.checked = items.deckTracker;

      if (items.uiEnabled) {
        deckTrackerEl.removeAttribute('disabled');
      } else {
        deckTrackerEl.setAttribute('disabled', !items.uiEnabled);
      }
    });
  }

  restoreOptions();
  uiEl.addEventListener('change', saveOptions);
  deckTrackerEl.addEventListener('change', saveOptions);
});
